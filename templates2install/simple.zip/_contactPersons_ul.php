<h3>Ansprechpartner:</h3>
<ul class="contactpersons">
	{{list}}
</ul>