<?php
$modulehelper->remove
([
	'#MODULEPATH',
]);

$modulehelper->remove_option('modul_test_installed');

$XenuxDB->removeTable('test1');
?>