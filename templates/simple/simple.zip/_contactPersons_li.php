<li>
	<span class="title">{{name}}</span>
	{{position}}<br/>
	{{email}}
</li>
